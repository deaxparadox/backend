def add(): 
    print("This is the add function from: Django poll app.")